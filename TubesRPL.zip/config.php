<?php

$host 		= "localhost";
$username	= "root";
$password	= "";
$dbname		= "rpl";

$link = mysqli_connect($host, $username, $password, $dbname)
or die("Salah server, nama pengguna, atau passwordnya!"); 
?>
