<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<?php
echo ("Kahfi ganteng");
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;?>
<center> <br><br>
	<div class="w3-container w3-red">
		<p><?php echo !extension_loaded('openssl')?"Not Available":"Available";?></p>
	</div>
</center> 

<?php
//Load Composer's autoloader
require '../vendor/autoload.php';
if (!isset($_COOKIE['username'])){
		header("Location : http://localhost/TubesRPL/login.html");
	}
$uname = $_COOKIE['username'];
echo ($uname);
echo ("Kahfi ganteng");
if(isset($_POST['Kirim'])){
$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
	
	
	


	
    //Server settings
    
                                    // Enable verbose debug output
    $mail->isSMTP();   
    $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
		)
	);                                   // Set mailer to use SMTP
    $mail->Host = "smtp.gmail.com";  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'mobilstomoto@gmail.com';                 // SMTP username
    $mail->Password = 'B4nd4r0_4l4y';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('mobilstomoto@gmail.com');
    $mail->addAddress('neolostox@gmail.com');     			// Add a recipient
    /*$mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo('info@example.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');

    //Attachments
    $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name*/

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $uname; 					//pakai username session
    $mail->Body    = $_POST['Teks'];
    $mail->AltBody = $_POST['Teks'];

    $mail->send();
    ?> <center> <?php
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo; 
}
}
?> </center>
<style>
    body{background-color: #ffffff; color: #333;}
    .main{box-shadow: 0 .125rem .25rem rgba(0,0,0,.075)!important; margin-top: 10px;}
</style>
<br><br>
<body class="bg-light">	
	<center><h3>Tuliskan Pesanmu pada Admin EToko di sini!</h3>

	<h4>Subjek email merupakan <?php echo $uname;?></h4><br></center>
	<div class = "container main">
		<form action="" method="POST">
            <div class="form-group">
                <input class="form-control" type="text" name="Teks" placeholder="Teks" size=20/>
            </div>
            <br>
             <input type="submit" class="btn btn-dark btn-block" name="Kirim" value="Kirim" />
        </form>
    </div>
    
</body>
           

