<?php
	include_once 'includes/dbh.inc.php';
	include_once 'includes/header.php';
	session_start();
?>

<h1>Account Detail</h1>

<html>
<head>
</head>

<body>
<div id="center_button">
    <button onclick="location.href='index.php'">Back to Profile</button>
</div>
</body>
</html>

<?php
	echo "<br>";
	print('Ganti gambar profil anda'). "<br>";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Account Detail</title>
    <link rel="stylesheet" type="text/css.css" href="style.css">
</head>
<body class="bg-light">
<form action="" method="POST" enctype="multipart/form-data">
	<input type="file" name="file">
	<button type="submit" name ="submit">Change Image</button>
</form>	
</body>
</html>

<?php
	if(isset($_POST['submit'])){
                move_uploaded_file($_FILES['file']['tmp_name'],"image_upload/".$_FILES['file']['name']);
                $conn = mysqli_connect("localhost","root","","rpl");
                $q = mysqli_query($conn,"UPDATE users SET profile_image = '".$_FILES['file']['name']."' WHERE user_uid = '".$_SESSION['user_uid']."'");
    }
	echo "<br>";
	$sqlProf = "SELECT *FROM users WHERE user_uid= '".$_SESSION['user_uid']."';";
	$resultProf = mysqli_query($conn, $sqlProf);
	$resultProfCheck = mysqli_num_rows($resultProf);

	if ($resultProfCheck > 0) {
		while ($row = mysqli_fetch_assoc($resultProf)) {
			if($row['profile_image'] == ""){
				echo "<img width='250' height='250' src='image_upload/default.jpg' alt='Default Profile Pic'>";
			} else {
				echo "<img width='250' height='250' src='image_upload/".$row['profile_image']."' alt='Profile Pic'>";
			}
			echo "<br>";
			print('Username: ');
			echo $row['user_uid'] . "<br>";
			print('Nama Depan: ');
			echo $row['user_first'] . "<br>";
			print('Nama Akhir: ');
			echo $row['user_last'] . "<br>";
			print('e-mail: ');
			echo $row['user_email'] . "<br>";
			print('Password: ');
			echo $row['user_pwd'] . "<br>";
			echo "<br>";
		}
	}
?>

</body>
</html>
