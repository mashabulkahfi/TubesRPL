<?php
	include_once 'includes/dbh.inc.php';
	include_once 'includes/header.php';
	session_start();
?>

<h1>Orders</h1>

<html>
<head>
</head>

<body>
<div id="center_button">
    <button onclick="location.href='index.php'">Back to Profile</button>
</div>
</body>
</html>

<?php
	echo "<br>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Orders</title>
    <link rel="stylesheet" type="text/css.css" href="style.css">
</head>
<body class="bg-light">

<?php
	$sqlTrans = "SELECT * FROM transaksi WHERE user_uid = '".$_SESSION['user_uid']."';"; 
	$sqlBar = "SELECT * FROM barang INNER JOIN transaksi ON id_barang = barang_id";
	$resultTrans = mysqli_query($conn, $sqlTrans);
	$resultBar = mysqli_query($conn, $sqlBar);
	$resultTransCheck = mysqli_num_rows($resultTrans);
	$resultBarCheck = mysqli_num_rows($resultBar);
	
	print('Transaksi: '). "<br>";
	if (($resultTransCheck > 0) && ($resultBarCheck > 0)) { 
			while ($rowTrans = mysqli_fetch_assoc($resultTrans)) {
				$rowBar = mysqli_fetch_assoc($resultBar);
				echo "<br>";
				print('ID Transaksi: ');
				echo $rowTrans['id_transaksi'] . "<br>";
				print('Tanggal Transaksi: ');
				echo $rowTrans['tanggal_transaksi'] . "<br>";
				print('Alamat Transaksi: ');
				echo $rowTrans['alamat_transaksi'] . "<br>";
				print('Id Barang: ');
				echo $rowTrans['barang_id'] . "<br>";
				echo "<img width='100' height='100' src='gambar_barang/".$rowBar['gambar_barang']."' alt='gambar_barang'>"."<br>";
				print('Jumlah Barang: ');
				echo $rowTrans['jumlah_barang'] . "<br>";
				print('Harga Barang: ');
				echo $rowBar['harga_barang'] . "<br>";
				print('Total Harga: ');
				echo $rowTrans['jumlah_barang'] * $rowBar['harga_barang'] . "<br>";
				echo "<br>";
		}
	} else {
		echo "<br>";
		print('Belum ada transaksi yang dilakukan');
	}
?>
